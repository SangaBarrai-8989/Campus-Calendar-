# Campus Calendar — HTML, CSS & JavaScript

A frontend-only implementation based on the Figma overview screenshot shared in chat. It uses the Campus Calendar name, navy/sky-blue palette, left navigation, calendar grid, schedule cards, and matching account form layouts.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a browser, or use VS Code Live Server.
3. No Node.js, npm, or backend is required.

## Pages
- `index.html` — Home calendar
- `pages/events.html` — Events
- `pages/create-event.html` — Create event
- `pages/classes.html` — My Classes
- `pages/event-details.html` — Event list/details entry point
- `pages/admin.html` — Admin dashboard demo
- `pages/profile.html` — Profile
- `pages/users.html` — Users
- `pages/signin.html` — Sign in
- `pages/signup.html` — Create account
- `pages/forgot-password.html` — Forgot password
- `pages/password-reset.html` — Password reset

## Notes
- The SVG logo is a recreated vector approximation based on the small logo visible in the screenshot. It is not the original exported Figma logo asset.
- The supplied Figma image is a zoomed-out overview, so pixel-perfect matching cannot be guaranteed from it alone. For exact matching, export the original logo and each Figma frame at 1x/2x and replace `assets/logo.svg` or share the exports.
- This is a frontend demo only. localStorage is used for demo event data. Authentication, email sending, shared database, and real user permissions are not implemented.
