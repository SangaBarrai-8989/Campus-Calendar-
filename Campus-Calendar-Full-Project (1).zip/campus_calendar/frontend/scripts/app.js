const API = "";
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
function getToken(){return localStorage.getItem("cc_token")||""}
function getUser(){try{return JSON.parse(localStorage.getItem("cc_user")||"null")}catch{return null}}
function setSession(data){if(data.token)localStorage.setItem("cc_token",data.token);if(data.user)localStorage.setItem("cc_user",JSON.stringify(data.user))}
function clearSession(){localStorage.removeItem("cc_token");localStorage.removeItem("cc_user")}
async function api(path, options={}) {
  const headers={"Content-Type":"application/json",...(options.headers||{})};
  if(getToken())headers.Authorization="Bearer "+getToken();
  const res=await fetch(API+"/api"+path,{...options,headers});
  const data=await res.json().catch(()=>({message:"Unexpected server response"}));
  if(!res.ok)throw new Error(data.message||"Request failed");
  return data;
}
function notice(message,type="success"){let el=$("#notice");if(!el){el=document.createElement("div");el.id="notice";el.className="notice";const target=$(".page-content")||$(".auth-card");target?.prepend(el)}el.className="notice "+(type==="error"?"error":"success");el.textContent=message;el.scrollIntoView({block:"nearest",behavior:"smooth"})}
function initials(name="Student"){return name.trim().split(/\s+/).slice(0,2).map(x=>x[0]?.toUpperCase()||"").join("")}
function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function sidebar(active="Home"){
 const links=[["Home","index.html","▦"],["My Classes","index.html#classes","▣"],["Events","event-details.html","◷"],["Create Event","create-event.html","＋"],["Profile","profile.html","♙"],["Admin Dashboard","admin.html","▤"]];
 return `<aside class="sidebar"><a class="brand" href="index.html"><span class="brand-mark">C</span><span>Campus<small>CALENDAR</small></span></a><nav class="nav">${links.map(([label,url,icon])=>`<a class="${active===label?"active":""}" href="${url}"><span class="nav-icon">${icon}</span>${label}</a>`).join("")}</nav><div class="sidebar-bottom"><a href="profile.html">⚙ Settings</a><a href="#" id="logout-link">↪ Sign out</a></div></aside>`;
}
function topbar(){const u=getUser()||{name:"Guest Student"};return `<header class="topbar"><button class="icon-button hamburger" id="menu-toggle" aria-label="Open menu">☰</button><div class="search"><span>⌕</span><input id="global-search" placeholder="Search events, classes..." /></div><div class="top-actions"><button class="icon-button" aria-label="Notifications">♧</button><a class="user-chip" href="profile.html"><span class="avatar">${escapeHtml(initials(u.name))}</span><span class="user-name">${escapeHtml(u.name)}</span></a></div></header><nav class="mobile-nav" id="mobile-nav"><a href="index.html">Home</a><a href="create-event.html">Create Event</a><a href="event-details.html">Events</a><a href="profile.html">Profile</a><a href="admin.html">Admin Dashboard</a></nav>`}
function shell(active,title,subtitle,content,action=""){document.body.innerHTML=`<div class="app">${sidebar(active)}<main class="main">${topbar()}<div class="page-heading"><div><h1>${title}</h1><p>${subtitle}</p></div>${action}</div><div class="page-content">${content}</div></main></div>`;$("#logout-link")?.addEventListener("click",e=>{e.preventDefault();clearSession();location.href="sign-in.html"});$("#menu-toggle")?.addEventListener("click",()=>$("#mobile-nav").classList.toggle("open"));$("#global-search")?.addEventListener("keydown",e=>{if(e.key==="Enter")location.href="event-details.html?q="+encodeURIComponent(e.target.value)})}
function authShell(title,subtitle,content){document.body.innerHTML=`<div class="auth-page"><section class="auth-side"><a class="brand" href="index.html"><span class="brand-mark">C</span><span>Campus<small>CALENDAR</small></span></a><div><h1>Plan your campus life, beautifully.</h1><p>Bring classes, events, and your schedule together in one calm, organized space.</p></div><small>© ${new Date().getFullYear()} Campus Calendar</small></section><main class="auth-main"><section class="auth-card"><h2>${title}</h2><p>${subtitle}</p>${content}</section></main></div>`}
function requireSignIn(){if(!getToken()){location.href="sign-in.html";return false}return true}
function fmtDate(s){if(!s)return "Date not set";const d=new Date(s+"T12:00:00");return d.toLocaleDateString(undefined,{month:"short",day:"numeric",year:"numeric"})}
function statusTag(s="Pending"){const cls=s.toLowerCase();return `<span class="tag ${cls}">${escapeHtml(s)}</span>`}

// Browser requests use the server's session cookie; fetch keeps same-origin cookies by default.
