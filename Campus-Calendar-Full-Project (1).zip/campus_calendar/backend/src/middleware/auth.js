function requireAuth(req,res,next){if(!req.session.userId)return res.status(401).json({message:"Please sign in to continue."});next()}
function requireAdmin(req,res,next){if(!req.session.userId)return res.status(401).json({message:"Please sign in to continue."});const db=require("../db").read();const user=db.users.find(u=>u.id===req.session.userId);if(!user||user.role!=="admin")return res.status(403).json({message:"Administrator access is required."});next()}
module.exports={requireAuth,requireAdmin};
