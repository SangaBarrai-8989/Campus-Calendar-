const router=require("express").Router();
const crypto=require("crypto");
const db=require("../db");
const {requireAuth}=require("../middleware/auth");
router.use(requireAuth);
router.get("/",(req,res)=>{const data=db.read();const events=data.events.filter(e=>e.ownerId===req.session.userId||e.audience==="All students"||data.users.find(u=>u.id===req.session.userId)?.role==="admin");res.json({events:events.sort((a,b)=>(a.date||"").localeCompare(b.date||""))})});
router.post("/",(req,res)=>{const {title,type,date,time,endTime,location,organizer,audience,description}=req.body||{};if(!title?.trim()||!type||!date||!time)return res.status(400).json({message:"Title, type, date and start time are required."});const data=db.read();const user=data.users.find(u=>u.id===req.session.userId);const event={id:crypto.randomUUID(),title:title.trim(),type,date,time,endTime:endTime||"",location:(location||"").trim(),organizer:(organizer||user?.name||"").trim(),audience:audience||"My classes",description:(description||"").trim(),status:"Pending",ownerId:req.session.userId,createdAt:new Date().toISOString()};data.events.push(event);db.write(data);res.status(201).json({event})});
router.get("/:id",(req,res)=>{const data=db.read();const e=data.events.find(x=>x.id===req.params.id);if(!e)return res.status(404).json({message:"Event not found."});if(e.ownerId!==req.session.userId&&e.audience!=="All students")return res.status(403).json({message:"You cannot view this event."});res.json({event:e})});
module.exports=router;
