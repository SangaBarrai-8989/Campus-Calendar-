const router=require("express").Router();
const db=require("../db");
const {requireAdmin}=require("../middleware/auth");
router.use(requireAdmin);
router.get("/summary",(req,res)=>{const data=db.read();res.json({totalEvents:data.events.length,pendingEvents:data.events.filter(e=>e.status==="Pending").length,totalUsers:data.users.length,events:data.events.slice().sort((a,b)=>b.createdAt.localeCompare(a.createdAt))})});
router.patch("/events/:id",(req,res)=>{const {status}=req.body||{};if(!["Approved","Rejected"].includes(status))return res.status(400).json({message:"Status must be Approved or Rejected."});const data=db.read();const event=data.events.find(e=>e.id===req.params.id);if(!event)return res.status(404).json({message:"Event not found."});event.status=status;db.write(data);res.json({event})});
module.exports=router;
