const router=require("express").Router();
const db=require("../db");
const {requireAuth}=require("../middleware/auth");
router.use(requireAuth);
router.get("/me",(req,res)=>{const data=db.read();const u=data.users.find(x=>x.id===req.session.userId);if(!u)return res.status(404).json({message:"User not found."});const {id,name,email,organization,role}=u;res.json({user:{id,name,email,organization,role}})});
router.patch("/me",(req,res)=>{const data=db.read();const u=data.users.find(x=>x.id===req.session.userId);if(!u)return res.status(404).json({message:"User not found."});const {name,organization}=req.body||{};if(!name?.trim())return res.status(400).json({message:"Name is required."});u.name=name.trim();u.organization=(organization||"").trim();db.write(data);res.json({user:{id:u.id,name:u.name,email:u.email,organization:u.organization,role:u.role}})});
module.exports=router;
