const fs = require("fs");
const path = require("path");
const dir = path.join(__dirname, "..", "data");
const file = path.join(dir, "db.json");
function ensure(){if(!fs.existsSync(dir))fs.mkdirSync(dir,{recursive:true});if(!fs.existsSync(file))fs.writeFileSync(file,JSON.stringify({users:[],events:[],resetTokens:[]},null,2))}
function read(){ensure();return JSON.parse(fs.readFileSync(file,"utf8"))}
function write(data){ensure();fs.writeFileSync(file,JSON.stringify(data,null,2))}
module.exports={read,write};
