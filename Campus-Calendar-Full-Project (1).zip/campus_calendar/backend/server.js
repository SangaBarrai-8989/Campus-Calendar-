const express = require("express");
const session = require("express-session");
const path = require("path");
const fs = require("fs");
const authRoutes = require("./src/routes/auth");
const eventRoutes = require("./src/routes/events");
const userRoutes = require("./src/routes/users");
const adminRoutes = require("./src/routes/admin");

const app = express();
const PORT = process.env.PORT || 3000;
const FRONTEND = path.join(__dirname, "..", "frontend");
app.use(express.json({limit:"100kb"}));
app.use(session({
  secret: process.env.SESSION_SECRET || "replace-this-demo-secret-before-deployment",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly:true, sameSite:"lax", secure:false, maxAge: 1000*60*60*8 }
}));
app.use("/api/auth", authRoutes);
app.use("/api/events", eventRoutes);
app.use("/api/users", userRoutes);
app.use("/api/admin", adminRoutes);
app.use(express.static(FRONTEND));
app.get("/", (req,res)=>res.sendFile(path.join(FRONTEND,"routes","sign-in.html")));
app.get("/health", (req,res)=>res.json({ok:true,service:"Campus Calendar API"}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({message:"An unexpected server error occurred."})});
app.listen(PORT,()=>console.log(`Campus Calendar running at http://localhost:${PORT}`));
