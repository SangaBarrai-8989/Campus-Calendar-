# Campus Calendar — Full-stack starter project

A responsive Campus Calendar prototype based on the supplied Figma overview. It includes:
- Sign in, create account, forgot password, reset password
- Home calendar and today's schedule
- Create event and event details
- Admin dashboard
- Profile
- Express backend API with JSON-file persistence for demo purposes

## Requirements
- Node.js 18 or newer
- npm

## Run locally
1. Extract the ZIP.
2. Open a terminal in the `campus-calendar` folder.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the server:
   ```bash
   npm start
   ```
5. Open `http://localhost:3000`.

## Demo notes
- The backend stores data in `backend/data/db.json`; this is suitable for learning/demo work, not production.
- Create an account first, then sign in.
- Password reset is simulated: the API returns a demo reset token. In a real deployment, send a one-time link by email and store secrets securely.
- The first registered account is not automatically an administrator. For the demo admin page, a user can open `admin.html`; production needs server-side role checks and proper authorization.
- Do not deploy this demo with real personal information. Before production, add a real database, email delivery, stronger validation, CSRF protection, rate limiting, secure session settings, and admin authorization.
